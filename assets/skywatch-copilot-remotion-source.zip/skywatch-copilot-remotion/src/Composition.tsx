import React from "react";
import {
  AbsoluteFill,
  CanvasImage,
  Composition,
  Easing,
  interpolate,
  staticFile,
  useCurrentFrame,
} from "remotion";

type Props = {
  readonly question: string;
  readonly pilotName: string;
};

const COLORS = {
  deep: "#041722",
  panel: "#082532",
  panelRaised: "#0b2e3d",
  line: "rgba(166, 222, 246, 0.18)",
  sky: "#77d6ff",
  pale: "#d9f5ff",
  ink: "#f3fbff",
  muted: "#9fb9c8",
  green: "#69f0ae",
};

const DotGrid: React.FC = () => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill
      style={{
        opacity: interpolate(frame, [0, 24], [0, 0.22], {
          extrapolateLeft: "clamp",
          extrapolateRight: "clamp",
          easing: Easing.bezier(0.16, 1, 0.3, 1),
        }),
        backgroundImage: "radial-gradient(rgba(119,214,255,.34) 1.2px, transparent 1.2px)",
        backgroundSize: "34px 34px",
        translate: `${interpolate(frame, [0, 300], ["0px 0px", "17px 9px"], {
          extrapolateLeft: "clamp",
          extrapolateRight: "clamp",
        })}`,
      }}
    />
  );
};

const TypingDots: React.FC<{readonly start: number; readonly end: number}> = ({start, end}) => {
  const frame = useCurrentFrame();
  return (
    <div
      style={{
        display: "flex",
        gap: 9,
        opacity: interpolate(frame, [start, start + 8, end - 6, end], [0, 1, 1, 0], {
          extrapolateLeft: "clamp",
          extrapolateRight: "clamp",
          easing: [Easing.bezier(0.16, 1, 0.3, 1), Easing.linear, Easing.linear],
        }),
      }}
    >
      {[0, 1, 2].map((index) => (
        <span
          key={index}
          style={{
            width: 11,
            height: 11,
            borderRadius: "50%",
            background: COLORS.sky,
            opacity: interpolate((frame - start - index * 5) % 24, [0, 8, 16, 24], [0.35, 1, 0.35, 0.35], {
              extrapolateLeft: "clamp",
              extrapolateRight: "clamp",
            }),
            scale: interpolate((frame - start - index * 5) % 24, [0, 8, 16, 24], [0.86, 1.18, 0.86, 0.86], {
              extrapolateLeft: "clamp",
              extrapolateRight: "clamp",
              output: "perceptual-scale",
            }),
          }}
        />
      ))}
    </div>
  );
};

const ChatDemo: React.FC<Props> = ({question, pilotName}) => {
  const frame = useCurrentFrame();
  const typedQuestion = question.slice(
    0,
    Math.floor(
      interpolate(frame, [30, 72], [0, question.length], {
        extrapolateLeft: "clamp",
        extrapolateRight: "clamp",
        easing: Easing.linear,
      }),
    ),
  );

  const modules = [
    ["Aerodynamics", "14 lessons"],
    ["Airspace", "8 lessons"],
    ["Instruments", "7 lessons"],
    ["Weather", "7 lessons"],
  ];
  const resources = ["Free Pilot Training", "FAA PHAK", "FAA ACS", "Flying Handbook"];

  return (
    <AbsoluteFill
      style={{
        backgroundColor: COLORS.deep,
        color: COLORS.ink,
        fontFamily: "Inter, Arial, sans-serif",
        overflow: "hidden",
      }}
    >
      <AbsoluteFill
        style={{
          background:
            "radial-gradient(circle at 78% 12%, rgba(26,125,167,.34), transparent 32%), radial-gradient(circle at 15% 86%, rgba(7,83,112,.38), transparent 34%)",
        }}
      />
      <DotGrid />

      <div
        style={{
          position: "absolute",
          inset: "68px 88px",
          border: `1px solid ${COLORS.line}`,
          borderRadius: 34,
          background: "rgba(5,27,38,.92)",
          boxShadow: "0 40px 110px rgba(0,0,0,.42), 0 0 60px rgba(119,214,255,.05)",
          overflow: "hidden",
          opacity: interpolate(frame, [0, 18, 282, 299], [0, 1, 1, 0], {
            extrapolateLeft: "clamp",
            extrapolateRight: "clamp",
            easing: [Easing.bezier(0.16, 1, 0.3, 1), Easing.linear, Easing.bezier(0.4, 0, 1, 1)],
          }),
          scale: interpolate(frame, [0, 22], [0.965, 1], {
            extrapolateLeft: "clamp",
            extrapolateRight: "clamp",
            easing: Easing.bezier(0.16, 1, 0.3, 1),
            output: "perceptual-scale",
          }),
        }}
      >
        <div
          style={{
            height: 92,
            padding: "0 34px",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            borderBottom: `1px solid ${COLORS.line}`,
            background: "rgba(7,36,50,.82)",
          }}
        >
          <div style={{display: "flex", alignItems: "center", gap: 20}}>
            <CanvasImage src={staticFile("skywatch-logo-white.png")} style={{width: 170, height: 34}} />
            <span style={{width: 1, height: 32, background: COLORS.line}} />
            <div>
              <div style={{fontSize: 24, fontWeight: 800}}>Co-Pilot</div>
              <div style={{fontSize: 15, color: COLORS.muted}}>Open Pilot Handbook</div>
            </div>
          </div>
          <div style={{display: "flex", alignItems: "center", gap: 10, fontSize: 17, color: COLORS.pale}}>
            <span
              style={{
                width: 10,
                height: 10,
                borderRadius: "50%",
                background: COLORS.green,
                boxShadow: `0 0 ${interpolate(frame % 60, [0, 30, 60], [0, 16, 0], {
                  extrapolateLeft: "clamp",
                  extrapolateRight: "clamp",
                })}px rgba(105,240,174,.7)`,
              }}
            />
            Source-aware
          </div>
        </div>

        <div style={{padding: "32px 38px", height: "calc(100% - 92px)", position: "relative"}}>
          <div
            style={{
              marginLeft: "auto",
              maxWidth: 740,
              padding: "20px 24px",
              borderRadius: "24px 24px 6px 24px",
              background: "linear-gradient(135deg,#1a8fbc,#11759f)",
              boxShadow: "0 18px 40px rgba(12,105,143,.24)",
              fontSize: 29,
              lineHeight: 1.32,
              opacity: interpolate(frame, [18, 30], [0, 1], {
                extrapolateLeft: "clamp",
                extrapolateRight: "clamp",
                easing: Easing.bezier(0.16, 1, 0.3, 1),
              }),
              translate: interpolate(frame, [18, 34], ["30px 0px", "0px 0px"], {
                extrapolateLeft: "clamp",
                extrapolateRight: "clamp",
                easing: Easing.bezier(0.16, 1, 0.3, 1),
              }),
            }}
          >
            <div style={{fontSize: 16, color: "rgba(255,255,255,.76)", marginBottom: 7, fontWeight: 700}}>{pilotName}</div>
            {typedQuestion}
            <span style={{opacity: frame < 78 && frame % 16 < 8 ? 1 : 0, color: "white"}}>▍</span>
          </div>

          <div
            style={{
              marginTop: 26,
              display: "flex",
              gap: 14,
              alignItems: "flex-start",
              opacity: interpolate(frame, [82, 94], [0, 1], {
                extrapolateLeft: "clamp",
                extrapolateRight: "clamp",
                easing: Easing.bezier(0.16, 1, 0.3, 1),
              }),
            }}
          >
            <div
              style={{
                width: 50,
                height: 50,
                flex: "0 0 50px",
                display: "grid",
                placeItems: "center",
                borderRadius: 16,
                background: "linear-gradient(145deg,#0f6f98,#0a405a)",
                color: "white",
                fontSize: 22,
                fontWeight: 900,
              }}
            >
              SW
            </div>

            <div
              style={{
                minWidth: 0,
                maxWidth: 925,
                padding: "22px 26px",
                border: `1px solid ${COLORS.line}`,
                borderRadius: "8px 24px 24px 24px",
                background: COLORS.panelRaised,
                boxShadow: "0 20px 44px rgba(0,0,0,.2)",
              }}
            >
              <div style={{fontSize: 17, color: COLORS.sky, fontWeight: 800, marginBottom: 12}}>SkyWatch Co-Pilot</div>
              {frame < 116 ? (
                <TypingDots start={86} end={116} />
              ) : (
                <div>
                  <div style={{display: "flex", alignItems: "center", justifyContent: "space-between", gap: 18, marginBottom: 14}}>
                    <div style={{fontSize: 25, lineHeight: 1.25, fontWeight: 800}}>
                      Absolutely. Here’s your complete learning path.
                    </div>
                    <div style={{flex: "0 0 auto", color: COLORS.deep, background: COLORS.sky, borderRadius: 999, padding: "8px 14px", fontWeight: 900, fontSize: 16}}>
                      64 lessons · 12 modules
                    </div>
                  </div>
                  <div style={{display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 8}}>
                    {modules.map(([name, count], index) => (
                      <div
                        key={name}
                        style={{
                          padding: "11px 12px",
                          border: `1px solid ${COLORS.line}`,
                          borderRadius: 12,
                          background: "rgba(119,214,255,.055)",
                          opacity: interpolate(frame, [126 + index * 24, 140 + index * 24], [0, 1], {
                            extrapolateLeft: "clamp",
                            extrapolateRight: "clamp",
                            easing: Easing.bezier(0.16, 1, 0.3, 1),
                          }),
                          translate: interpolate(frame, [126 + index * 18, 140 + index * 18], ["0px 10px", "0px 0px"], {
                            extrapolateLeft: "clamp",
                            extrapolateRight: "clamp",
                            easing: Easing.bezier(0.16, 1, 0.3, 1),
                          }),
                        }}
                      >
                        <div style={{color: COLORS.pale, fontWeight: 800, fontSize: 17}}>{name}</div>
                        <div style={{color: COLORS.muted, fontSize: 13, marginTop: 3}}>{count}</div>
                      </div>
                    ))}
                  </div>
                  <div
                    style={{
                      display: "flex",
                      gap: 9,
                      alignItems: "center",
                      marginTop: 13,
                      opacity: interpolate(frame, [202, 220], [0, 1], {
                        extrapolateLeft: "clamp",
                        extrapolateRight: "clamp",
                        easing: Easing.bezier(0.16, 1, 0.3, 1),
                      }),
                    }}
                  >
                    <span style={{fontSize: 14, color: COLORS.muted, marginRight: 2}}>Built from</span>
                    {resources.map((source) => (
                      <span key={source} style={{padding: "5px 10px", border: `1px solid ${COLORS.line}`, borderRadius: 999, color: COLORS.sky, fontSize: 14, fontWeight: 800}}>
                        {source}
                      </span>
                    ))}
                  </div>
                  <div style={{display: "flex", alignItems: "center", justifyContent: "space-between", marginTop: 13, padding: "10px 12px", borderRadius: 12, background: "rgba(105,240,174,.08)", border: "1px solid rgba(105,240,174,.22)", opacity: interpolate(frame, [226, 244], [0, 1], {extrapolateLeft: "clamp", extrapolateRight: "clamp"})}}>
                    <span style={{fontSize: 16, color: COLORS.pale}}><b>Start here:</b> Module 1 · How an airplane flies</span>
                    <span style={{fontSize: 15, color: COLORS.green, fontWeight: 900}}>Begin lesson 1 →</span>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <div
        style={{
          position: "absolute",
          left: 0,
          right: 0,
          bottom: 20,
          textAlign: "center",
          color: COLORS.muted,
          fontSize: 15,
          letterSpacing: 0.2,
          opacity: interpolate(frame, [236, 252], [0, 1], {
            extrapolateLeft: "clamp",
            extrapolateRight: "clamp",
            easing: Easing.bezier(0.16, 1, 0.3, 1),
          }),
        }}
      >
        Learn · ask · practice · review · progress through all 64 lessons
      </div>
    </AbsoluteFill>
  );
};

export const MyComposition: React.FC = () => {
  return (
    <Composition
      id="SkyWatchCoPilotChat"
      component={ChatDemo}
      durationInFrames={300}
      fps={30}
      width={1280}
      height={720}
      defaultProps={{
        question: "I’m starting from zero. Can you teach me everything I need for private pilot ground school?",
        pilotName: "Student pilot",
      }}
    />
  );
};
